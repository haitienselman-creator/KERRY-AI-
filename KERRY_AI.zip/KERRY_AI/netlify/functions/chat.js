// API key stays on the server. Never put it in index.html or app.js.
exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: corsHeaders(), body: "" };
  }
  if (event.httpMethod !== "POST") {
    return json(405, { error: "Méthode non autorisée." });
  }
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return json(500, { error: "La clé API n’est pas configurée dans Netlify." });

  let body;
  try { body = JSON.parse(event.body || "{}"); }
  catch { return json(400, { error: "Message invalide." }); }

  const messages = Array.isArray(body.messages) ? body.messages : [];
  const allowed = messages
    .filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
    .slice(-20)
    .map(m => ({ role: m.role, content: m.content.slice(0, 8000) }));
  if (!allowed.length || !allowed.some(m => m.role === "user")) {
    return json(400, { error: "Écris d’abord un message." });
  }

  try {
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        instructions: "Tu es KERRY AI, un assistant utile, clair et respectueux. Réponds dans la langue utilisée par la personne, notamment le français ou le créole haïtien. Pour les devoirs, explique les étapes simplement. N'invente pas de faits lorsque tu n'es pas sûr.",
        input: allowed.map(m => ({
          role: m.role,
          content: [{ type: "input_text", text: m.content }]
        })),
        max_output_tokens: 900
      })
    });
    const data = await response.json();
    if (!response.ok) {
      const detail = data?.error?.message || "Le fournisseur AI a refusé la requête.";
      return json(response.status === 401 ? 502 : 502, { error: `Erreur API : ${detail}` });
    }
    const reply = (data.output || [])
      .flatMap(item => item.content || [])
      .filter(part => part.type === "output_text")
      .map(part => part.text)
      .join("\n")
      .trim();
    if (!reply) return json(502, { error: "La réponse AI était vide. Réessaie." });
    return json(200, { reply });
  } catch (error) {
    return json(502, { error: "Impossible de joindre le service AI. Vérifie la connexion." });
  }
};

function corsHeaders() {
  return { "Content-Type": "application/json; charset=utf-8" };
}
function json(statusCode, body) {
  return { statusCode, headers: corsHeaders(), body: JSON.stringify(body) };
}
