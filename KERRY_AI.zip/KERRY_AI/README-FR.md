# KERRY AI — version bêta

KERRY AI est une interface de chat web installable sur téléphone. Le serveur Netlify appelle l'API OpenAI : la clé API n'est jamais placée dans le code du navigateur.

## 1. Ce qu'il faut
- Un compte GitHub.
- Un compte Netlify connecté à GitHub.
- Une clé API OpenAI et un moyen de paiement/crédit API actif si requis. L'abonnement ChatGPT et la facturation API sont séparés.

## 2. Mettre le projet sur GitHub
1. Téléchargez et décompressez `KERRY_AI.zip`.
2. Ouvrez votre dépôt `kerry-ai` sur GitHub.
3. Utilisez **Add file → Upload files** et téléversez tous les fichiers et dossiers de ce projet (pas le dossier ZIP lui-même).
4. Validez avec **Commit changes**.

## 3. Déployer sur Netlify
1. Connectez-vous à Netlify et choisissez **Add new site → Import an existing project**.
2. Connectez GitHub et sélectionnez le dépôt `kerry-ai`.
3. Laissez le répertoire de publication sur `.` et déployez. Le fichier `netlify.toml` définit la fonction serveur.
4. Dans le site Netlify, ouvrez **Site configuration / Environment variables** (ou **Project configuration → Environment variables**) et ajoutez :
   - Nom : `OPENAI_API_KEY`
   - Valeur : votre clé API secrète
   - Facultatif : `OPENAI_MODEL` = `gpt-4.1-mini`
5. Redéployez le site après avoir ajouté la variable.

**Sécurité :** ne publiez jamais la clé API dans `index.html`, `app.js`, GitHub, une capture d'écran ou un message public. Si vous l'avez déjà publiée, révoquez-la et créez-en une nouvelle.

## 4. Tester
Ouvrez l'URL HTTPS fournie par Netlify et envoyez « Bonjour ». Si le chat affiche une erreur, vérifiez les variables d'environnement et les journaux de la fonction `chat`.

## 5. Installer sur Android
Dans Chrome sur Android, ouvrez le site Netlify, appuyez sur le menu ⋮ puis **Installer l'application** ou **Ajouter à l'écran d'accueil** (le libellé varie). Cela crée une version installable de type PWA. Ce n'est pas encore un APK publié sur Play Store ; nous pourrons préparer l'emballage APK dans une étape suivante.

## Limites de cette bêta
- Les conversations ne sont pas sauvegardées dans un compte et disparaissent après actualisation.
- Il n'y a pas encore de connexion utilisateur, limitation d'usage ni système de paiement.
- Avant d'ouvrir le site au public, ajoutez une limite de requêtes côté serveur et des contrôles anti-abus pour éviter des coûts API imprévus.
