const form=document.getElementById('chatForm');
const input=document.getElementById('messageInput');
const messages=document.getElementById('messages');
const welcome=document.getElementById('welcome');
const sendButton=document.getElementById('sendButton');
const sidebar=document.getElementById('sidebar');
let history=[];
let busy=false;

function addMessage(role,text){
  welcome.classList.add('hidden');
  const row=document.createElement('div');
  row.className=`message ${role}`;
  const avatar=document.createElement('div');
  avatar.className='avatar';
  avatar.textContent=role==='user'?'VO':'K';
  const bubble=document.createElement('div');
  bubble.className='bubble';
  bubble.textContent=text;
  row.append(avatar,bubble);
  messages.appendChild(row);
  row.scrollIntoView({behavior:'smooth',block:'end'});
  return bubble;
}
function setBusy(value){busy=value;sendButton.disabled=value;input.disabled=value;sendButton.textContent=value?'…':'↑';}
async function sendMessage(text){
  const clean=text.trim();
  if(!clean||busy)return;
  addMessage('user',clean);
  history.push({role:'user',content:clean});
  input.value='';resizeInput();setBusy(true);
  const answerBubble=addMessage('assistant','KERRY AI réfléchit…');
  answerBubble.classList.add('typing');
  try{
    const response=await fetch('/.netlify/functions/chat',{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({messages:history})
    });
    const data=await response.json().catch(()=>({}));
    if(!response.ok)throw new Error(data.error||`Erreur serveur (${response.status}).`);
    const answer=data.reply||'Je n’ai pas reçu de réponse. Réessaie.';
    answerBubble.classList.remove('typing');answerBubble.textContent=answer;
    history.push({role:'assistant',content:answer});
  }catch(err){
    answerBubble.classList.remove('typing');
    answerBubble.textContent='Je n’ai pas pu répondre. '+(err.message||'Vérifie la connexion et la configuration API.');
    history.pop();
  }finally{setBusy(false);input.focus();}
}
function resizeInput(){input.style.height='auto';input.style.height=Math.min(input.scrollHeight,180)+'px';}
form.addEventListener('submit',e=>{e.preventDefault();sendMessage(input.value);});
input.addEventListener('input',resizeInput);
input.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();form.requestSubmit();}});
document.querySelectorAll('[data-prompt]').forEach(btn=>btn.addEventListener('click',()=>sendMessage(btn.dataset.prompt)));
document.getElementById('newChat').addEventListener('click',()=>{history=[];messages.replaceChildren();welcome.classList.remove('hidden');sidebar.classList.remove('open');input.focus();});
document.getElementById('clearChat').addEventListener('click',()=>{history=[];messages.replaceChildren();welcome.classList.remove('hidden');});
document.getElementById('menuButton').addEventListener('click',()=>sidebar.classList.toggle('open'));
if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));}
